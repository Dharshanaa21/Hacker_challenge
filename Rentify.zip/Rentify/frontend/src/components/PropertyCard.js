import React from 'react';

const PropertyCard = ({ property }) => {
    return (
        <div className="property-card">
            <h3>{property.title}</h3>
            <p><strong>Location:</strong> {property.location}</p>
            <p><strong>Bedrooms:</strong> {property.bedrooms}</p>
            <p><strong>Bathrooms:</strong> {property.bathrooms}</p>
            <p><strong>Price:</strong> ${property.price}</p>
            <p><strong>Description:</strong> {property.description}</p>
        </div>
    );
};

export default PropertyCard;
