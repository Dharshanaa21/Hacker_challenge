import React, { useState } from 'react';

const PropertyForm = () => {
    const [formData, setFormData] = useState({
        title: '',
        location: '',
        bedrooms: 0,
        bathrooms: 0,
        price: 0,
        description: ''
    });

    const handleChange = e => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSubmit = e => {
        e.preventDefault();
        // You can implement the property form submission logic here
        console.log('Form submitted:', formData);
    };

    return (
        <div>
            <h2>Post a Property</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label htmlFor="title">Title:</label>
                    <input 
                        type="text" 
                        id="title" 
                        name="title" 
                        value={formData.title} 
                        onChange={handleChange} 
                        required 
                    />
                </div>
                <div>
                    <label htmlFor="location">Location:</label>
                    <input 
                        type="text" 
                        id="location" 
                        name="location" 
                        value={formData.location} 
                        onChange={handleChange} 
                        required 
                    />
                </div>
                <div>
                    <label htmlFor="bedrooms">Bedrooms:</label>
                    <input 
                        type="number" 
                        id="bedrooms" 
                        name="bedrooms" 
                        value={formData.bedrooms} 
                        onChange={handleChange} 
                        required 
                    />
                </div>
                <div>
                    <label htmlFor="bathrooms">Bathrooms:</label>
                    <input 
                        type="number" 
                        id="bathrooms" 
                        name="bathrooms" 
                        value={formData.bathrooms} 
                        onChange={handleChange} 
                        required 
                    />
                </div>
                <div>
                    <label htmlFor="price">Price:</label>
                    <input 
                        type="number" 
                        id="price" 
                        name="price" 
                        value={formData.price} 
                        onChange={handleChange} 
                        required 
                    />
                </div>
                <div>
                    <label htmlFor="description">Description:</label>
                    <textarea 
                        id="description" 
                        name="description" 
                        value={formData.description} 
                        onChange={handleChange} 
                        required 
                    />
                </div>
                <button type="submit">Post Property</button>
            </form>
        </div>
    );
};

export default PropertyForm;
