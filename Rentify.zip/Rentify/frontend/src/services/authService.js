// authService.js

// Function to register a new user
export const registerUser = async (userData) => {
    try {
        // Make a POST request to your backend API endpoint for user registration
        const response = await fetch('/api/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        });

        // Check if the request was successful
        if (!response.ok) {
            // Throw an error if registration failed
            throw new Error('Registration failed');
        }

        // Parse the response JSON data
        const data = await response.json();

        // Return the user data
        return data;
    } catch (error) {
        // Log and rethrow any errors that occur during registration
        console.error('Error registering user:', error);
        throw error;
    }
};

// Function to log in a user
export const loginUser = async (userData) => {
    try {
        // Make a POST request to your backend API endpoint for user login
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        });

        // Check if the request was successful
        if (!response.ok) {
            // Throw an error if login failed
            throw new Error('Login failed');
        }

        // Parse the response JSON data
        const data = await response.json();

        // Return the user data
        return data;
    } catch (error) {
        // Log and rethrow any errors that occur during login
        console.error('Error logging in user:', error);
        throw error;
    }
};
