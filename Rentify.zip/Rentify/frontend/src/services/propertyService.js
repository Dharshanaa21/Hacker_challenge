/// propertyService.js

// Function to fetch all properties
export const fetchProperties = async () => {
    try {
        // Make a GET request to your backend API endpoint to fetch all properties
        const response = await fetch('/api/properties');

        // Check if the request was successful
        if (!response.ok) {
            // Throw an error if fetching properties failed
            throw new Error('Failed to fetch properties');
        }

        // Parse the response JSON data
        const data = await response.json();

        // Return the fetched properties
        return data;
    } catch (error) {
        // Log and rethrow any errors that occur while fetching properties
        console.error('Error fetching properties:', error);
        throw error;
    }
};

// Function to add a new property
export const addProperty = async (propertyData) => {
    try {
        // Make a POST request to your backend API endpoint to add a new property
        const response = await fetch('/api/properties', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(propertyData)
        });

        // Check if the request was successful
        if (!response.ok) {
            // Throw an error if adding property failed
            throw new Error('Failed to add property');
        }

        // Parse the response JSON data
        const data = await response.json();

        // Return the newly added property
        return data;
    } catch (error) {
        // Log and rethrow any errors that occur while adding property
        console.error('Error adding property:', error);
        throw error;
    }
};

// Function to delete a property
export const deleteProperty = async (propertyId) => {
    try {
        // Make a DELETE request to your backend API endpoint to delete a property
        const response = await fetch(`/api/properties/${propertyId}`, {
            method: 'DELETE'
        });

        // Check if the request was successful
        if (!response.ok) {
            // Throw an error if deleting property failed
            throw new Error('Failed to delete property');
        }

        // Return a success message
        return 'Property deleted successfully';
    } catch (error) {
        // Log and rethrow any errors that occur while deleting property
        console.error('Error deleting property:', error);
        throw error;
    }
};
