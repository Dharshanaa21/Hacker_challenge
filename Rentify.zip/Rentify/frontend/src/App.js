// App.js

import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import UserRegistrationForm from './components/UserRegistrationForm';
import UserLoginForm from './components/UserLoginForm';
import PropertyList from './components/PropertyList';
import PropertyForm from './components/PropertyForm';

const App = () => {
    return (
        <Router>
            <div className="app">
                <Switch>
                    <Route path="/register" component={UserRegistrationForm} />
                    <Route path="/login" component={UserLoginForm} />
                    <Route path="/properties" component={PropertyList} />
                    <Route path="/add-property" component={PropertyForm} />
                    {/* Add more routes for seller and buyer flows */}
                </Switch>
            </div>
        </Router>
    );
};

export default App;
