// Example usage in your application file

// MongoDB connection URI
const mongoURI = 'mongodb://localhost/rentify';

// JWT secret key
const jwtSecret = 'your_jwt_secret';

// Example usage of the configuration settings
console.log('MongoDB URI:', mongoURI);
console.log('JWT Secret:', jwtSecret);
