// propertyController.js

const Property = require('../models/Property');

// Method to fetch all properties
exports.getAllProperties = async (req, res) => {
    try {
        const properties = await Property.find();
        res.status(200).json(properties);
    } catch (error) {
        console.error('Error fetching properties:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

// Method to create a new property
exports.createProperty = async (req, res) => {
    const { title, description, location, price, bedrooms, bathrooms, area, imageUrl } = req.body;

    try {
        const newProperty = new Property({
            title,
            description,
            location,
            price,
            bedrooms,
            bathrooms,
            area,
            imageUrl
        });

        await newProperty.save();

        res.status(201).json({ message: 'Property created successfully', property: newProperty });
    } catch (error) {
        console.error('Error creating property:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

// Method to update a property by ID
exports.updateProperty = async (req, res) => {
    const { id } = req.params;
    const { title, description, location, price, bedrooms, bathrooms, area, imageUrl } = req.body;

    try {
        const property = await Property.findById(id);

        if (!property) {
            return res.status(404).json({ message: 'Property not found' });
        }

        // Update property fields
        property.title = title;
        property.description = description;
        property.location = location;
        property.price = price;
        property.bedrooms = bedrooms;
        property.bathrooms = bathrooms;
        property.area = area;
        property.imageUrl = imageUrl;

        await property.save();

        res.status(200).json({ message: 'Property updated successfully', property });
    } catch (error) {
        console.error('Error updating property:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

// Method to delete a property by ID
exports.deleteProperty = async (req, res) => {
    const { id } = req.params;

    try {
        const property = await Property.findByIdAndDelete(id);

        if (!property) {
            return res.status(404).json({ message: 'Property not found' });
        }

        res.status(200).json({ message: 'Property deleted successfully', property });
    } catch (error) {
        console.error('Error deleting property:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
