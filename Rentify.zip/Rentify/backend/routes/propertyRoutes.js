// propertyRoutes.js

const express = require('express');
const router = express.Router();
const propertyController = require('../controllers/propertyController');

// Route to fetch all properties
router.get('/', propertyController.getAllProperties);

// Route to create a new property
router.post('/', propertyController.createProperty);

// Route to update a property by ID
router.put('/:id', propertyController.updateProperty);

// Route to delete a property by ID
router.delete('/:id', propertyController.deleteProperty);

module.exports = router;
